fx_version 'cerulean'
game 'rdr3'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

author 'chester-studio'
description 'Police system VORP/RSG: multas, esposas, carcel, armeria, almacen, testigo, registro armas'
version '1.0.0'

shared_scripts {
  '@ox_lib/init.lua',
  'shared/config.lua',
}

server_scripts {
  '@oxmysql/lib/MySQL.lua',
  'server/server.lua',
}

client_scripts {
  'client/client.lua',
}

dependencies {
  'chester-api',
'ox_lib',
  'oxmysql'
}
