-- ======================================================
--  LOCKNAME_CHECK + CHESTER-API + UPDATE CHECKER
-- ======================================================
local RES_NAME = GetCurrentResourceName()
local EXPECTED = (Config.LockResourceName or 'chester-police')

local function PrintCreator()
  print(('^1[%s]^7 Porfavor contacta con el creador.'):format(RES_NAME))
end

if RES_NAME ~= EXPECTED then
  print(('^1[%s]^7 Nombre inválido. Debe llamarse: ^3%s^7'):format(RES_NAME, EXPECTED))
  PrintCreator()
  CreateThread(function()
    Wait(1000)
    StopResource(RES_NAME)
  end)
  return
end

local function ChesterNotify(src, data)
  if Config.ChesterAPI and Config.ChesterAPI.enabled and GetResourceState(Config.ChesterAPI.resource) == 'started' then
    local ok = pcall(function()
      exports[Config.ChesterAPI.resource]:Notify(src, data.type or 'inform', data.description or '')
    end)
    if ok then return end

    ok = pcall(function()
      exports[Config.ChesterAPI.resource]:NotifyRight(src, data.description or '', data.type or 'inform')
    end)
    if ok then return end
  end
  ChesterNotify(src, data)
end

local function StartUpdateChecker()
  if not (Config.UpdateCheck and Config.UpdateCheck.enabled) then return end
  local owner = tostring(Config.UpdateCheck.owner or '')
  local repo  = tostring(Config.UpdateCheck.repo or '')
  if owner == '' or repo == '' or owner == 'CHANGE_ME' or repo == 'CHANGE_ME' then
    print(('^3[%s]^7 UpdateCheck: configura Config.UpdateCheck.owner/repo para ver tus últimas actualizaciones de GitHub.'):format(RES_NAME))
    return
  end

  local mode = (Config.UpdateCheck.mode or 'release'):lower()
  local url
  if mode == 'commit' then
    local ref = tostring(Config.UpdateCheck.ref or 'main')
    url = ('https://api.github.com/repos/%s/%s/commits/%s'):format(owner, repo, ref)
  else
    url = ('https://api.github.com/repos/%s/%s/releases/latest'):format(owner, repo)
  end

  local localVersion = GetResourceMetadata(RES_NAME, 'version', 0) or '0.0.0'
  local interval = tonumber(Config.UpdateCheck.intervalMinutes) or 60
  interval = math.max(10, interval)

  local function checkOnce()
    PerformHttpRequest(url, function(code, body, headers)
      if code ~= 200 or not body then
        print(('^1[%s]^7 UpdateCheck falló (HTTP %s).'):format(RES_NAME, tostring(code)))
        return
      end

      local ok, data = pcall(function() return json.decode(body) end)
      if not ok or not data then
        print(('^1[%s]^7 UpdateCheck: respuesta inválida de GitHub.'):format(RES_NAME))
        return
      end

      if mode == 'commit' then
        local remote = data.sha and tostring(data.sha):sub(1, 7) or 'N/A'
        print(('^2[%s]^7 GitHub commit: ^3%s^7 | Local version: ^3%s^7'):format(RES_NAME, remote, localVersion))
      else
        local remote = data.tag_name and tostring(data.tag_name) or nil
        if remote then
          if remote ~= localVersion then
            print(('^3[%s]^7 Hay una actualización disponible: ^2%s^7 (GitHub) vs ^1%s^7 (local).'):format(RES_NAME, remote, localVersion))
          else
            print(('^2[%s]^7 Estás actualizado: ^3%s^7'):format(RES_NAME, localVersion))
          end
        else
          print(('^3[%s]^7 UpdateCheck: no se encontró tag_name en releases/latest.'):format(RES_NAME))
        end
      end
    end, 'GET', '', { ['Accept'] = 'application/vnd.github+json' })
  end

  CreateThread(function()
    Wait(4000)
    checkOnce()
    while true do
      Wait(interval * 60000)
      checkOnce()
    end
  end)
end

StartUpdateChecker()

-- ======================================================

local function dbg(...)
  if Config.Debug then
    print('[chester_police]', ...)
  end
end

-- =========================
--  FRAMEWORK BRIDGE
-- =========================
local Bridge = { fw = (Config.Framework or 'vorp'):lower() }
local RSGCore = nil

if Bridge.fw == 'rsg' then
  RSGCore = exports['rsg-core']:GetCoreObject()
end

local function GetVorpCore()
  local ok, core = pcall(function()
    return exports.vorp_core:GetCore()
  end)
  return ok and core or nil
end

local function GetIdentifier(src)
  if Bridge.fw == 'rsg' then
    local Player = RSGCore and RSGCore.Functions.GetPlayer(src)
    if not Player then return nil end
    local cid = Player.PlayerData and Player.PlayerData.citizenid
    local name = 'Unknown'
    if Player.PlayerData and Player.PlayerData.charinfo then
      local ci = Player.PlayerData.charinfo
      name = ((ci.firstname or '') .. ' ' .. (ci.lastname or '')):gsub('^%s*(.-)%s*$', '%1')
      if name == '' then name = 'Unknown' end
    end
    return tostring(cid), name
  end

  local Core = GetVorpCore()
  if Core then
    local User = Core.getUser(src)
    if User and User.getUsedCharacter then
      local Char = User.getUsedCharacter
      local cid = Char.charIdentifier or Char.charidentifier or Char.identifier
      local name = ((Char.firstname or '') .. ' ' .. (Char.lastname or '')):gsub('^%s*(.-)%s*$', '%1')
      if cid then return tostring(cid), (name ~= '' and name or GetPlayerName(src)) end
    end
  end

  -- fallback
  for _, id in ipairs(GetPlayerIdentifiers(src)) do
    if id:find('license:') then return id, GetPlayerName(src) end
  end
  return tostring(src), GetPlayerName(src)
end

local function IsPolice(src)
  if not Config.RequirePoliceJob then return true end

  if Bridge.fw == 'rsg' then
    local Player = RSGCore and RSGCore.Functions.GetPlayer(src)
    if not Player then return false end
    local job = Player.PlayerData and Player.PlayerData.job and Player.PlayerData.job.name
    return job and Config.PoliceJobs[job] == true
  end

  local Core = GetVorpCore()
  if not Core then return false end
  local User = Core.getUser(src)
  if not User or not User.getUsedCharacter then return false end
  local Char = User.getUsedCharacter
  local job = Char.job
  return job and Config.PoliceJobs[job] == true
end

-- =========================
--  MONEY REMOVE (fine pay)
-- =========================
local function RemoveMoney(src, account, amount, reason)
  amount = tonumber(amount) or 0
  if amount <= 0 then return false end

  if Bridge.fw == 'rsg' then
    local Player = RSGCore and RSGCore.Functions.GetPlayer(src)
    if not Player then return false end
    account = (account == 'bank') and 'bank' or 'cash'
    Player.Functions.RemoveMoney(account, amount, reason or 'police-fine')
    return true
  end

  local Core = GetVorpCore()
  if not Core then return false end
  local User = Core.getUser(src)
  if not User or not User.getUsedCharacter then return false end
  local Char = User.getUsedCharacter

  local t = (account == 'bank') and 1 or 0 -- 0=money/cash, 1=bank (común en VORP)
  if Char.removeCurrency then
    Char.removeCurrency(t, amount)
    return true
  end

  if Core.delMoney then
    Core.delMoney(src, t, amount)
    return true
  end

  return false
end

-- =========================
--  STASH CREATE/OPEN
-- =========================
local function EnsureStash(stashId, label, slots, maxWeight)
  if Bridge.fw == 'rsg' then
    exports['rsg-inventory']:CreateInventory(stashId, {
      label = label,
      maxweight = maxWeight,
      slots = slots
    })
  else
    exports.vorp_inventory:registerInventory({
      id = stashId,
      name = label,
      limit = slots,
      acceptWeapons = true,
      shared = true,
      ignoreItemStackLimit = true,
      whitelistItems = false,
      UsePermissions = false,
      UseBlackList = false,
      whitelistWeapons = false,
      webhook = ''
    })
  end
end

AddEventHandler('onResourceStart', function(res)
  if res ~= GetCurrentResourceName() then return end
  EnsureStash(Config.Armory.stashId, Config.Armory.label, Config.Armory.slots, Config.Armory.maxWeight)
  EnsureStash(Config.Storage.stashId, Config.Storage.label, Config.Storage.slots, Config.Storage.maxWeight)
end)

RegisterNetEvent('chester_police:server:openStash', function(which)
  local src = source
  if not IsPolice(src) then return end

  if which == 'armory' then
    if Bridge.fw == 'rsg' then
      exports['rsg-inventory']:OpenInventory(src, Config.Armory.stashId, {
        label = Config.Armory.label, maxweight = Config.Armory.maxWeight, slots = Config.Armory.slots
      })
    else
      exports.vorp_inventory:openInventory(src, Config.Armory.stashId)
    end
  elseif which == 'storage' then
    if Bridge.fw == 'rsg' then
      exports['rsg-inventory']:OpenInventory(src, Config.Storage.stashId, {
        label = Config.Storage.label, maxweight = Config.Storage.maxWeight, slots = Config.Storage.slots
      })
    else
      exports.vorp_inventory:openInventory(src, Config.Storage.stashId)
    end
  end
end)

-- =========================
--  MULTAS
-- =========================
lib.callback.register('chester_police:cb:getUnpaidFines', function(src)
  local owner_id = select(1, GetIdentifier(src))
  if not owner_id then return {} end
  local rows = MySQL.query.await('SELECT * FROM police_fines WHERE owner_id = ? AND paid = 0 ORDER BY created_at DESC', { owner_id })
  return rows or {}
end)

RegisterNetEvent('chester_police:server:issueFine', function(target, amount, reason)
  local src = source
  if not IsPolice(src) then return end
  target = tonumber(target)
  amount = tonumber(amount) or 0
  reason = tostring(reason or 'Sin motivo')

  if not target or target <= 0 then return end
  if amount <= 0 or amount > Config.Fines.maxAmount then return end

  local owner_id, owner_name = GetIdentifier(target)
  local issuer_id, issuer_name = GetIdentifier(src)
  if not owner_id or not issuer_id then return end

  MySQL.insert.await(
    'INSERT INTO police_fines (owner_id, owner_name, amount, reason, issuer_id, issuer_name) VALUES (?, ?, ?, ?, ?, ?)',
    { owner_id, owner_name, amount, reason, issuer_id, issuer_name }
  )

  ChesterNotify(target, { type='error', description=('Te han puesto una multa: $%d (%s)'):format(amount, reason) })
  ChesterNotify(src, { type='success', description='Multa emitida correctamente.' })
end)

RegisterNetEvent('chester_police:server:payFine', function(fineId, payMethod)
  local src = source
  fineId = tonumber(fineId)
  payMethod = (payMethod == 'bank') and 'bank' or 'cash'
  if not fineId then return end

  local owner_id = select(1, GetIdentifier(src))
  if not owner_id then return end

  local fine = MySQL.single.await('SELECT * FROM police_fines WHERE id = ? AND owner_id = ? AND paid = 0', { fineId, owner_id })
  if not fine then
    ChesterNotify(src, { type='error', description='No existe esa multa o ya está pagada.' })
    return
  end

  local ok = RemoveMoney(src, payMethod, tonumber(fine.amount), 'police-fine-pay')
  if not ok then
    ChesterNotify(src, { type='error', description='No se pudo cobrar (revisa tu sistema de dinero).' })
    return
  end

  MySQL.update.await('UPDATE police_fines SET paid = 1, paid_at = NOW(), pay_method = ? WHERE id = ?', { payMethod, fineId })
  ChesterNotify(src, { type='success', description=('Multa pagada: $%d'):format(fine.amount) })
end)

-- =========================
--  BADGE
-- =========================
lib.callback.register('chester_police:cb:getBadge', function(src)
  local owner_id = select(1, GetIdentifier(src))
  if not owner_id then return nil end
  local row = MySQL.single.await('SELECT badge FROM police_badges WHERE owner_id = ?', { owner_id })
  return row and row.badge or nil
end)

RegisterNetEvent('chester_police:server:setBadge', function(badge)
  local src = source
  if not IsPolice(src) then return end
  badge = tostring(badge or ''):sub(1, 32)
  if badge == '' then return end

  local owner_id = select(1, GetIdentifier(src))
  if not owner_id then return end

  MySQL.update.await('INSERT INTO police_badges (owner_id, badge) VALUES (?, ?) ON DUPLICATE KEY UPDATE badge = VALUES(badge)', { owner_id, badge })
  ChesterNotify(src, { type='success', description='Placa actualizada.' })
end)

-- =========================
--  JAIL
-- =========================
RegisterNetEvent('chester_police:server:jailPlayer', function(target, minutes, reason)
  local src = source
  if not IsPolice(src) then return end
  target = tonumber(target)
  minutes = tonumber(minutes) or 0
  reason = tostring(reason or 'Sin motivo')

  if not target or minutes < Config.Jail.minMinutes or minutes > Config.Jail.maxMinutes then return end

  local owner_id = select(1, GetIdentifier(target))
  local jailed_by = select(1, GetIdentifier(src))
  if not owner_id then return end

  local jail_until = os.time() + (minutes * 60)
  MySQL.update.await(
    'INSERT INTO police_jail (owner_id, jail_until, jailed_by, jailed_reason) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE jail_until = VALUES(jail_until), jailed_by = VALUES(jailed_by), jailed_reason = VALUES(jailed_reason)',
    { owner_id, jail_until, jailed_by, reason }
  )

  TriggerClientEvent('chester_police:client:doJail', target, jail_until, Config.Jail.coords, Config.Jail.releaseCoords)
  ChesterNotify(src, { type='success', description=('Enviado a la cárcel %d min.'):format(minutes) })
end)

lib.callback.register('chester_police:cb:getJailState', function(src)
  local owner_id = select(1, GetIdentifier(src))
  if not owner_id then return nil end
  local row = MySQL.single.await('SELECT jail_until FROM police_jail WHERE owner_id = ?', { owner_id })
  if not row then return nil end
  return tonumber(row.jail_until)
end)

RegisterNetEvent('chester_police:server:clearJail', function()
  local src = source
  local owner_id = select(1, GetIdentifier(src))
  if not owner_id then return end
  MySQL.update.await('DELETE FROM police_jail WHERE owner_id = ?', { owner_id })
end)

-- =========================
--  CUFFS
-- =========================
RegisterNetEvent('chester_police:server:setCuffed', function(target, state)
  local src = source
  if not IsPolice(src) then return end
  target = tonumber(target)
  if not target then return end
  TriggerClientEvent('chester_police:client:setCuffed', target, state and true or false)
end)

-- =========================
--  /TESTIGO (ALERT SYSTEM)
-- =========================
local TestigoCooldown = {}
local Alerts = {}

local function PushAlert(coords, bySrc)
  local id = tostring(os.time()) .. '_' .. tostring(math.random(1000,9999))
  Alerts[id] = {
    id = id,
    coords = coords,
    expiresAt = os.time() + Config.Testigo.alertDurationSec,
    by = bySrc
  }
  return Alerts[id]
end

lib.callback.register('chester_police:cb:getAlerts', function(src)
  if not IsPolice(src) then return {} end
  local now = os.time()
  local out = {}
  for _, a in pairs(Alerts) do
    if a.expiresAt > now then out[#out+1] = a end
  end
  table.sort(out, function(x,y) return x.expiresAt > y.expiresAt end)
  return out
end)

RegisterCommand(Config.Testigo.command, function(src)
  src = tonumber(src)
  if not src then return end

  local now = os.time()
  local last = TestigoCooldown[src] or 0
  if now - last < Config.Testigo.cooldownSec then
    ChesterNotify(src, { type='error', description=('Espera %ds para usar /%s'):format(Config.Testigo.cooldownSec - (now-last), Config.Testigo.command) })
    return
  end
  TestigoCooldown[src] = now

  local ped = GetPlayerPed(src)
  if not ped or ped == 0 then return end
  local c = GetEntityCoords(ped)
  local alert = PushAlert({ x=c.x, y=c.y, z=c.z }, src)

  ChesterNotify(src, { type='error', description=Config.Testigo.notifyCivil })

  for _, ply in ipairs(GetPlayers()) do
    local p = tonumber(ply)
    if p and IsPolice(p) then
      TriggerClientEvent('chester_police:client:newAlert', p, alert)
      ChesterNotify(p, { type='inform', description=Config.Testigo.notifyPolice })
    end
  end
end, false)

-- =========================
--  WEAPON REGISTER
-- =========================
local function MakeSerial(len)
  local chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  local s = {}
  for i=1,len do
    local r = math.random(1, #chars)
    s[#s+1] = chars:sub(r,r)
  end
  return table.concat(s)
end

RegisterNetEvent('chester_police:server:registerWeapon', function(target, weaponName, weaponHash)
  local src = source
  if not IsPolice(src) then return end
  target = tonumber(target)
  if not target then return end

  local owner_id, owner_name = GetIdentifier(target)
  local reg_by, reg_by_name = GetIdentifier(src)
  if not owner_id or not reg_by then return end

  weaponName = tostring(weaponName or 'unknown'):sub(1,64)
  weaponHash = tonumber(weaponHash)

  local serial = MakeSerial(Config.WeaponRegister.serialLength)

  local ok = MySQL.insert.await(
    'INSERT INTO police_weapons (owner_id, owner_name, weapon_name, weapon_hash, serial, registered_by, registered_by_name) VALUES (?, ?, ?, ?, ?, ?, ?)',
    { owner_id, owner_name, weaponName, weaponHash, serial, reg_by, reg_by_name }
  )

  if ok then
    ChesterNotify(src, { type='success', description=('Arma registrada. Serial: %s'):format(serial) })
    ChesterNotify(target, { type='inform', description=('Tu arma fue registrada. Serial: %s'):format(serial) })
  else
    ChesterNotify(src, { type='error', description='No se pudo registrar (¿serial duplicado?).' })
  end
end)
