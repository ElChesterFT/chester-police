-- =========================
--  POLICE CLIENT (ox_lib UI)
-- =========================
local function IsPolice()
  if not Config.RequirePoliceJob then return true end

  if (Config.Framework or 'vorp'):lower() == 'rsg' then
    local RSGCore = exports['rsg-core']:GetCoreObject()
    local pdata = RSGCore.Functions.GetPlayerData()
    local job = pdata.job and pdata.job.name
    return job and Config.PoliceJobs[job] == true
  end

  -- VORP: validación real se hace en server (al ejecutar acciones).
  return true
end

local function vec3from4(v4) return vector3(v4.x, v4.y, v4.z) end
local function NearCoords(coords, dist)
  local pc = GetEntityCoords(PlayerPedId())
  return #(pc - coords) <= dist
end

-- =========================
--  NPC MULTAS
-- =========================
local finePed = nil

local function SpawnFineNPC()
  local m = joaat(Config.FinesNPC.model)
  RequestModel(m)
  while not HasModelLoaded(m) do Wait(0) end

  local c = Config.FinesNPC.coords
  finePed = CreatePed(m, c.x, c.y, c.z, c.w, false, false, false, false)
  SetEntityInvincible(finePed, true)
  SetBlockingOfNonTemporaryEvents(finePed, true)
  FreezeEntityPosition(finePed, true)
end

local function OpenFinesMenu()
  local fines = lib.callback.await('chester_police:cb:getUnpaidFines', false) or {}
  if #fines == 0 then
    lib.notify({ type='success', description='No tienes multas pendientes.' })
    return
  end

  local opts = {}
  for _, f in ipairs(fines) do
    opts[#opts+1] = {
      title = ('$%d - %s'):format(f.amount, f.reason),
      description = ('ID: %d | Emitida: %s'):format(f.id, tostring(f.created_at)),
      onSelect = function()
        lib.registerContext({
          id = 'chester_police_fine_pay_'..f.id,
          title = 'Pagar Multa',
          options = {
            {
              title = 'Pagar en efectivo',
              onSelect = function()
                TriggerServerEvent('chester_police:server:payFine', f.id, 'cash')
              end
            },
            {
              title = 'Pagar por banco',
              onSelect = function()
                TriggerServerEvent('chester_police:server:payFine', f.id, 'bank')
              end
            }
          }
        })
        lib.showContext('chester_police_fine_pay_'..f.id)
      end
    }
  end

  lib.registerContext({
    id = 'chester_police_fines',
    title = 'Multas Pendientes',
    options = opts
  })
  lib.showContext('chester_police_fines')
end

-- =========================
--  STASH OPEN
-- =========================
local function TryOpenStash(which)
  if not IsPolice() then
    lib.notify({ type='error', description='No eres policía.' })
    return
  end
  TriggerServerEvent('chester_police:server:openStash', which)
end

-- =========================
--  CUFFS
-- =========================
local cuffed = false

local function PlayAnim(dict, name, dur)
  RequestAnimDict(dict)
  while not HasAnimDictLoaded(dict) do Wait(0) end
  TaskPlayAnim(PlayerPedId(), dict, name, 1.0, 1.0, dur or 1500, 1, 0, false, false, false)
end

RegisterNetEvent('chester_police:client:setCuffed', function(state)
  cuffed = state
  if cuffed then
    PlayAnim(Config.Cuffs.suspectAnim.dict, Config.Cuffs.suspectAnim.name, Config.Cuffs.suspectAnim.durMs)
    lib.notify({ type='error', description='Estás esposado.' })
  else
    ClearPedTasks(PlayerPedId())
    lib.notify({ type='success', description='Te quitaron las esposas.' })
  end
end)

CreateThread(function()
  while true do
    if cuffed and Config.Cuffs.disableControls then
      DisableControlAction(0, 0x07CE1E61, true) -- attack
      DisableControlAction(0, 0xB2F377E8, true) -- aim
      DisableControlAction(0, 0x8FFC75D6, true) -- sprint
      DisableControlAction(0, 0xD9D0E1C0, true) -- jump
      DisableControlAction(0, 0xCEFD9220, true) -- E
      Wait(0)
    else
      Wait(250)
    end
  end
end)

local function GetNearestServerPlayer(range)
  local myCoords = GetEntityCoords(PlayerPedId())
  local nearestSid, nearestDist = nil, range + 0.01

  for _, pid in ipairs(GetActivePlayers()) do
    if pid ~= PlayerId() then
      local ped = GetPlayerPed(pid)
      if ped ~= 0 then
        local c = GetEntityCoords(ped)
        local d = #(myCoords - c)
        if d < nearestDist then
          nearestDist = d
          nearestSid = GetPlayerServerId(pid)
        end
      end
    end
  end

  return nearestSid, nearestDist
end

local function DoCuff(state)
  if not IsPolice() then return end
  local target = GetNearestServerPlayer(Config.Cuffs.range)
  if not target then
    lib.notify({ type='error', description='No hay nadie cerca.' })
    return
  end
  PlayAnim(Config.Cuffs.officerAnim.dict, Config.Cuffs.officerAnim.name, Config.Cuffs.officerAnim.durMs)
  TriggerServerEvent('chester_police:server:setCuffed', target, state)
end

-- =========================
--  JAIL (persist)
-- =========================
local jailUntil = nil
local jailRelease = nil

RegisterNetEvent('chester_police:client:doJail', function(untilTs, jailCoords, releaseCoords)
  jailUntil = untilTs
  jailRelease = releaseCoords
  local ped = PlayerPedId()
  SetEntityCoords(ped, jailCoords.x, jailCoords.y, jailCoords.z)
  SetEntityHeading(ped, jailCoords.w)
  lib.notify({ type='error', description='Has sido encarcelado.' })
end)

CreateThread(function()
  Wait(2500)
  local untilTs = lib.callback.await('chester_police:cb:getJailState', false)
  if untilTs and tonumber(untilTs) and tonumber(untilTs) > os.time() then
    jailUntil = tonumber(untilTs)
  end

  while true do
    if jailUntil and jailUntil > os.time() then
      local left = jailUntil - os.time()
      local mins = math.ceil(left / 60)
      lib.showTextUI(('⛓️ Cárcel: %d minuto(s) restantes'):format(mins), { position = 'top-center' })
      Wait(1000)
    elseif jailUntil and jailUntil <= os.time() then
      jailUntil = nil
      lib.hideTextUI()
      if jailRelease then
        local ped = PlayerPedId()
        SetEntityCoords(ped, jailRelease.x, jailRelease.y, jailRelease.z)
        SetEntityHeading(ped, jailRelease.w)
      end
      TriggerServerEvent('chester_police:server:clearJail')
      lib.notify({ type='success', description='Has salido de la cárcel.' })
      Wait(2000)
    else
      lib.hideTextUI()
      Wait(1500)
    end
  end
end)

-- =========================
--  ALERTS /TESTIGO + BLIP
-- =========================
local activeAlertBlips = {}

local function ClearAlertBlip(id)
  if activeAlertBlips[id] then
    RemoveBlip(activeAlertBlips[id])
    activeAlertBlips[id] = nil
  end
end

local function CreateAlertBlip(id, coords)
  ClearAlertBlip(id)
  -- Blip básico por coords (puede variar según build)
  local blip = Citizen.InvokeNative(0x554D9D53F696D002, 1664425300, coords.x, coords.y, coords.z)
  activeAlertBlips[id] = blip
  return blip
end

RegisterNetEvent('chester_police:client:newAlert', function(alert)
  if not IsPolice() then return end
  if not alert or not alert.id or not alert.coords then return end
  CreateAlertBlip(alert.id, alert.coords)
end)

local function OpenAlertsMenu()
  if not IsPolice() then return end
  local alerts = lib.callback.await('chester_police:cb:getAlerts', false) or {}
  if #alerts == 0 then
    lib.notify({ type='inform', description='No hay alertas activas.' })
    return
  end

  local opts = {}
  for _, a in ipairs(alerts) do
    opts[#opts+1] = {
      title = ('🚨 Testigo (%s)'):format(a.id),
      description = 'Marcar destino del testigo',
      onSelect = function()
        CreateAlertBlip(a.id, a.coords)
        lib.notify({ type='success', description='Destino marcado (blip creado).' })
      end
    }
  end

  lib.registerContext({
    id = 'chester_police_alerts',
    title = 'Alertas',
    options = opts
  })
  lib.showContext('chester_police_alerts')
end

-- =========================
--  MAIN MENU (ox_lib)
-- =========================
local function OpenPoliceMenu()
  if Config.RequirePoliceJob and not IsPolice() then
    lib.notify({ type='error', description='No eres policía.' })
    return
  end

  lib.registerContext({
    id = 'chester_police_main',
    title = '👮 Policía',
    options = {
      { title = '📌 Alertas (/testigo)', description='Ver y marcar destino', onSelect = OpenAlertsMenu },
      { title = '⛓️ Esposar (cercano)', onSelect = function() DoCuff(true) end },
      { title = '🔓 Quitar esposas (cercano)', onSelect = function() DoCuff(false) end },
      {
        title = '💸 Poner Multa (cercano)',
        onSelect = function()
          local target = GetNearestServerPlayer(2.0)
          if not target then return lib.notify({ type='error', description='No hay nadie cerca.' }) end
          local input = lib.inputDialog('Emitir Multa', {
            { type='number', label='Monto', required=true, min=1, max=Config.Fines.maxAmount },
            { type='input', label='Motivo', required=true, min=3, max=80 }
          })
          if not input then return end
          TriggerServerEvent('chester_police:server:issueFine', target, input[1], input[2])
        end
      },
      {
        title = '🚔 Enviar a cárcel (cercano)',
        onSelect = function()
          local target = GetNearestServerPlayer(2.0)
          if not target then return lib.notify({ type='error', description='No hay nadie cerca.' }) end
          local input = lib.inputDialog('Cárcel', {
            { type='number', label='Minutos (1-100)', required=true, min=Config.Jail.minMinutes, max=Config.Jail.maxMinutes },
            { type='input', label='Razón', required=false, min=0, max=120 }
          })
          if not input then return end
          TriggerServerEvent('chester_police:server:jailPlayer', target, input[1], input[2] or 'Sin motivo')
        end
      },
      {
        title = '🪪 Poner/Actualizar Placa',
        onSelect = function()
          local badge = lib.callback.await('chester_police:cb:getBadge', false)
          local input = lib.inputDialog('Placa', {
            { type='input', label='Número de Placa', default=tostring(badge or ''), required=true, min=2, max=16 }
          })
          if not input then return end
          TriggerServerEvent('chester_police:server:setBadge', input[1])
        end
      },
      {
        title = '🔫 Inscribir arma (cercano)',
        onSelect = function()
          local target = GetNearestServerPlayer(2.0)
          if not target then return lib.notify({ type='error', description='No hay nadie cerca.' }) end

          local ped = PlayerPedId()
          local weaponHash = GetSelectedPedWeapon(ped)
          if not weaponHash or weaponHash == 0 then
            return lib.notify({ type='error', description='Saca el arma en la mano para inscribirla.' })
          end

          TriggerServerEvent('chester_police:server:registerWeapon', target, tostring(weaponHash), weaponHash)
        end
      },
    }
  })

  lib.showContext('chester_police_main')
end

RegisterCommand(Config.OpenPoliceMenuCommand, function()
  OpenPoliceMenu()
end, false)

-- =========================
--  WORLD INTERACTIONS
-- =========================
CreateThread(function()
  SpawnFineNPC()

  while true do
    local sleep = 1000

    -- NPC multas
    if finePed and DoesEntityExist(finePed) then
      local c = Config.FinesNPC.coords
      if NearCoords(vec3from4(c), 2.0) then
        sleep = 0
        lib.showTextUI(('[E] %s'):format(Config.FinesNPC.promptText), { position='right-center' })
        if IsControlJustPressed(0, Config.InteractKey) then
          lib.hideTextUI()
          OpenFinesMenu()
          Wait(300)
        end
      end
    end

    -- Armería
    do
      local c = Config.Armory.coords
      if NearCoords(vec3from4(c), 2.0) then
        sleep = 0
        lib.showTextUI(('[E] %s'):format(Config.Armory.promptText), { position='right-center' })
        if IsControlJustPressed(0, Config.InteractKey) then
          lib.hideTextUI()
          TryOpenStash('armory')
          Wait(300)
        end
      end
    end

    -- Almacén
    do
      local c = Config.Storage.coords
      if NearCoords(vec3from4(c), 2.0) then
        sleep = 0
        lib.showTextUI(('[E] %s'):format(Config.Storage.promptText), { position='right-center' })
        if IsControlJustPressed(0, Config.InteractKey) then
          lib.hideTextUI()
          TryOpenStash('storage')
          Wait(300)
        end
      end
    end

    if sleep > 0 then
      lib.hideTextUI()
    end

    Wait(sleep)
  end
end)
