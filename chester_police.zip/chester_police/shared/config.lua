Config = {}

-- =========================
--  FRAMEWORK SWITCH
-- =========================
-- 'vorp' o 'rsg'
Config.Framework = 'vorp'

-- Debug (opcional)
Config.Debug = false

-- Jobs que reciben alertas /testigo y pueden usar menú policía
Config.PoliceJobs = {
  sheriff    = true,
  marshal    = true,
  valsheriff = true,
  rhdsheriff = true,
}

-- Si true: solo jobs Config.PoliceJobs pueden usar menú / stashes / esposas / cárcel
Config.RequirePoliceJob = true

-- =========================
--  COMANDOS / CONTROLES
-- =========================
Config.OpenPoliceMenuCommand = 'police'
Config.InteractKey = 0xCEFD9220 -- E (INPUT_CONTEXT)

-- =========================
--  NPC PAGO MULTAS (vector4)
-- =========================
Config.FinesNPC = {
  model = 'S_M_M_BANKCLERK_01',
  coords = vector4(-308.45, 776.72, 118.70, 10.0), -- CAMBIA
  promptText = 'Pagar Multas',
}

-- =========================
--  ARMERÍA / ALMACÉN (vector4) -> STASH
-- =========================
Config.Armory = {
  coords = vector4(-275.10, 805.30, 119.38, 90.0), -- CAMBIA
  stashId = 'police_armory',
  label = 'Armería Sheriff',
  slots = 80,
  maxWeight = 800000,
  promptText = 'Abrir Armería',
}

Config.Storage = {
  coords = vector4(-273.40, 807.10, 119.38, 90.0), -- CAMBIA
  stashId = 'police_storage',
  label = 'Almacén Sheriff',
  slots = 100,
  maxWeight = 1200000,
  promptText = 'Abrir Almacén',
}

-- =========================
--  CÁRCEL
-- =========================
Config.Jail = {
  coords = vector4(3356.12, -669.32, 46.26, 85.0), -- CAMBIA
  releaseCoords = vector4(3359.80, -670.10, 46.26, 90.0), -- CAMBIA
  minMinutes = 1,
  maxMinutes = 100,
}

-- =========================
--  ESPOSAS
-- =========================
Config.Cuffs = {
  range = 2.0,

  officerAnim = { dict = 'script_common@jail_cell@unlock', name = 'unlock', durMs = 1800 },
  suspectAnim = { dict = 'script_common@jail_cell@unlock', name = 'unlock', durMs = 1800 },

  disableControls = true,
}

-- =========================
--  /TESTIGO
-- =========================
Config.Testigo = {
  command = 'testigo',
  cooldownSec = 60,
  alertDurationSec = 300,
  notifyCivil = 'Un niño ha sido testigo de tu delito.',
  notifyPolice = '🚨 ¡Testigo reportado! Revisa el menú Policía → Alertas.',
  blip = {
    enabled = true,
  }
}

-- =========================
--  MULTAS
-- =========================
Config.Fines = {
  maxAmount = 5000,
}

-- =========================
--  REGISTRO ARMAS
-- =========================
Config.WeaponRegister = {
  serialLength = 10,
}
