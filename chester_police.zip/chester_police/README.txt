CHESTER_POLICE (VORP + RSG) - Instalación rápida

1) Requisitos:
   - oxmysql
   - ox_lib
   - VORP: vorp_core + vorp_inventory
   - RSG: rsg-core + rsg-inventory

2) Importa server/sql.sql en tu base de datos.

3) En server.cfg:
   ensure oxmysql
   ensure ox_lib

   # VORP
   ensure vorp_core
   ensure vorp_inventory

   # o RSG
   ensure rsg-core
   ensure rsg-inventory

   ensure chester_police

4) Config:
   - shared/config.lua
   - Cambia Config.Framework = 'vorp' o 'rsg'
   - Cambia coords vector4 (NPC, armería, almacén, cárcel)
   - Ajusta jobs en Config.PoliceJobs

USO:
- /police  -> menú policía
- /testigo -> alerta a policía (jobs configurados)

NOTA:
- El cobro de dinero está implementado con RemoveMoney en VORP/RSG.
  Si tu VORP usa otra API de dinero, dime cuál y lo adapto.
